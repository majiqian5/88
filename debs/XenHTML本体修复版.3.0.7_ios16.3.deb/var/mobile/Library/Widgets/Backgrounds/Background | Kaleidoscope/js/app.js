/* Background | Kaleidoscope — iOS 16 fullscreen fix
 * 原版把 window.innerWidth / window.innerHeight 在脚本解析时就抓下来当画布尺寸，
 * 一旦 webview 的 frame 还没算好（iOS 16 SpringBoard 里很常见），画布就会停在
 * 一个“正方形”的小尺寸上，导致背景只显示屏幕上半截。
 * 这里改成：画布尺寸永远跟随容器 / 视口的实时尺寸，并在多个时间点重新校正。
 */

var canvasEl = document.querySelector('#scene');

function viewportSize() {
  var w = 0,
    h = 0;
  var host = document.querySelector('.content') || document.body;

  if (canvasEl) {
    w = canvasEl.clientWidth || 0;
    h = canvasEl.clientHeight || 0;
  }
  if (!w || !h) {
    w = host ? host.clientWidth : 0;
    h = host ? host.clientHeight : 0;
  }
  if (!w) { w = document.documentElement.clientWidth || window.innerWidth || 0; }
  if (!h) { h = document.documentElement.clientHeight || window.innerHeight || 0; }
  if (!w) { w = (window.screen && window.screen.width) || 375; }
  if (!h) { h = (window.screen && window.screen.height) || 667; }

  return { w: Math.round(w), h: Math.round(h) };
}

function Tunnel() {
  var size = viewportSize();
  this.w = size.w || 1;
  this.h = size.h || 1;

  this.init();
  this.createMesh();

  this.handleEvents();

  window.requestAnimationFrame(this.render.bind(this));
}

Tunnel.prototype.init = function () {
  this.speed = 4;

  this.renderer = new THREE.WebGLRenderer({
    antialias: true,
    canvas: canvasEl,
    alpha: true
  });
  this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  // 第三个参数 false：别让 three 去写 canvas 的行内样式，尺寸完全由 CSS 控制
  this.renderer.setSize(this.w, this.h, false);

  this.camera = new THREE.PerspectiveCamera(15, this.w / this.h, 0.01, 10);
  this.camera.rotation.y = Math.PI;
  this.camera.position.z = 0.4;

  this.scene = new THREE.Scene();
  this.scene.fog = new THREE.Fog(0xffffff, 1, 1.9);
};

Tunnel.prototype.createMesh = function () {
  var points = [];
  var i = 0;
  var geometry = new THREE.Geometry();

  this.scene.remove(this.tubeMesh);

  for (i = 0; i < 5; i += 1) {
    points.push(new THREE.Vector3(0, 0, 3 * (i / 4)));
  }
  points[4].y = -0.06;

  this.curve = new THREE.CatmullRomCurve3(points);
  this.curve.type = 'catmullrom';

  geometry = new THREE.Geometry();
  geometry.vertices = this.curve.getPoints(120);
  this.splineMesh = new THREE.Line(geometry, new THREE.LineBasicMaterial());

  this.tubeMaterial = new THREE.MeshBasicMaterial({
    side: THREE.BackSide,
    vertexColors: THREE.FaceColors
  });

  this.tubeGeometry = new THREE.TubeGeometry(this.curve, 120, 0.02, 3, false);

  for (var i = 0; i < this.tubeGeometry.faces.length; i++) {
    var f = this.tubeGeometry.faces[i];
    var p = this.tubeGeometry.vertices[f.a];
    var color = new THREE.Color(
      'hsl(' +
        (Math.floor(Math.abs(noise.simplex3(p.x * 2, p.y * 4, p.z * 2)) * 80 * 100) * 0.01 + 180) +
        ',70%,60%)'
    );
    f.color = color;
  }

  this.tubeGeometry_o = this.tubeGeometry.clone();
  this.tubeMesh = new THREE.Mesh(this.tubeGeometry, this.tubeMaterial);

  this.scene.add(this.tubeMesh);
};

Tunnel.prototype.handleEvents = function () {
  window.addEventListener('resize', this.onResize.bind(this), false);
  window.addEventListener('orientationchange', this.onResize.bind(this), false);
  window.addEventListener('pageshow', this.onResize.bind(this), false);
  document.addEventListener('visibilitychange', this.onResize.bind(this), false);

  // 关键：iOS 16 上 webview 的 frame 会在挂载后过一会儿才变对，
  // 所以在头几秒里反复校正几次；之后低频巡检兜底。
  var self = this;
  var kicks = [0, 60, 150, 300, 600, 1000, 1500, 2500, 4000, 6000];
  kicks.forEach(function (ms) {
    window.setTimeout(function () {
      self.onResize();
    }, ms);
  });

  window.setInterval(function () {
    self.onResize();
  }, 1500);
};

Tunnel.prototype.onResize = function () {
  var size = viewportSize();
  if (!size.w || !size.h) return;
  if (size.w === this.w && size.h === this.h) return;

  this.w = size.w;
  this.h = size.h;

  this.camera.aspect = this.w / this.h;
  this.camera.updateProjectionMatrix();
  this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  this.renderer.setSize(this.w, this.h, false);
};

Tunnel.prototype.update = function () {
  this.createMesh();
};

Tunnel.prototype.updateCameraPosition = function () {
  this.camera.rotation.y = Math.PI - (0.5 * 0.1 - 0.05);
  this.camera.position.x = 0.5 * 0.008 - 0.004;
  this.camera.position.y = 0.5 * 0.008 - 0.004;
};

function hslToRgb(h, s, l) {
  var r, g, b;
  if (s == 0) {
    r = g = b = l; // achromatic
  } else {
    var hue2rgb = function hue2rgb(p, q, t) {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return [Math.round(r * 100) * 0.01, Math.round(g * 100) * 0.01, Math.round(b * 100) * 0.01];
}

Tunnel.prototype.updateCurve = function (delta) {
  var i = 0;
  var index = 0;
  var vertice_o = null;
  var vertice = null;
  for (i = 0; i < this.tubeGeometry.vertices.length; i += 1) {
    vertice_o = this.tubeGeometry_o.vertices[i];
    vertice = this.tubeGeometry.vertices[i];
    index = Math.floor(i / 120);
    vertice.x += ((vertice_o.x + this.splineMesh.geometry.vertices[index].x) - vertice.x) / 15;
    vertice.y += ((vertice_o.y + this.splineMesh.geometry.vertices[index].y) - vertice.y) / 15;
    vertice.applyAxisAngle(new THREE.Vector3(0, 0, 1), Math.abs(Math.cos(delta * 0.001 + vertice.z * 5)) * 0.1);
  }
  this.tubeGeometry.verticesNeedUpdate = true;

  this.curve.points[2].x = 100 * 0.5 - 50;
  this.curve.points[4].x = 100 * 0.5 - 50;

  this.curve.points[2].y = 100 * 0.5 - 50;
  this.curve.points[4].y = 100 * 0.5 - 50;

  this.splineMesh.geometry.verticesNeedUpdate = true;
  this.splineMesh.geometry.vertices = this.curve.getPoints(120);

  delta *= 0.0003;
  var f, p, h, rgb;
  for (var j = 0; j < this.tubeGeometry.faces.length; j++) {
    f = this.tubeGeometry.faces[j];
    p = this.tubeGeometry.vertices[f.a];
    h = (Math.floor(Math.abs(noise.simplex3(p.x * 2, p.y * 4, p.z * 2 + delta)) * 80 * 100) * 0.01 + 180) / 360;
    rgb = hslToRgb(h, 0.7, 0.6);
    f.color = new THREE.Color(rgb[0], rgb[1], rgb[2]);
  }
  this.tubeGeometry.elementsNeedUpdate = true;
};

Tunnel.prototype.render = function (delta) {
  this.updateCameraPosition();
  this.updateCurve(delta);
  this.renderer.render(this.scene, this.camera);
  window.requestAnimationFrame(this.render.bind(this));
};

window.onload = function () {
  window.tunnel = new Tunnel();
};
